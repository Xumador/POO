package encapsulamento.versao3;

public class Veiculo {
    private double carga;
    private double cargaMaxima;

    public Veiculo(double cargaMaxima){
        this.cargaMaxima = cargaMaxima * 9.81;
    }

    public double getCarga() {
        return carga / 9.81;
    }

    public double getCargaMaxima() {
        return cargaMaxima;
    }
    public boolean adicionarCaixa(double peso){
        double aux;
        aux = carga + NewtonsParaQuilos(peso);
        if(aux < cargaMaxima){
            carga = aux;
            return true;
        }
        else {
            return false;
        }
    }
    private double NewtonsParaQuilos(double peso){
        double newton;
        newton = peso * 9.81;
        return newton;
    }

}
